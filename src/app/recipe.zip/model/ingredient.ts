export interface Ingredient{
    name:string;
    amount:number;
}