import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-new',
  templateUrl: './recipe-new.component.html',
  styleUrls: ['./recipe-new.component.scss']
})
export class RecipeNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
